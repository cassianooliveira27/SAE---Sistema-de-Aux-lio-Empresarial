<div class="navbar">
  <div class="logo">
    <img src="logo.png" alt="Logo SAE">
    <h1>SAE</h1>
  </div>
  <nav>
    <a href="index.php">Início</a>
    <a href="funcionarios.php">Cadastrar Funcionários</a>
    <a href="cargos.php">Cadastrar Cargos</a>
    <a href="consulta_funcionarios.php">Consultar Funcionários</a>
    <a href="consulta_cargos.php">Consultar Cargos</a>
  </nav>
</div>
