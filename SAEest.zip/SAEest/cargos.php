<?php
require 'conect_bd.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_cargo']);
    $desc = trim($_POST['descricao']);
    $sal  = floatval($_POST['salario_base']);
    if ($nome !== '') {
        $stmt = $conn->prepare("INSERT INTO cargos (nome_cargo, descricao, salario_base) VALUES (?, ?, ?)");
        $stmt->bind_param('ssd', $nome, $desc, $sal);
        $stmt->execute();
        header('Location: consulta_cargos.php');
        exit;
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Cadastrar Cargo</title></head>
<link rel="stylesheet" href="style.css">
<body>
    <div class="header">
    <div class="header-content">
        <img src="logo.png" alt="SAE Logo" class="logo">
        <div>
            <h1 class="header-title">SAE</h1>
            <p class="header-subtitle">Sistema Auxiliar Empresarial</p>
        </div>
    </div>
</div>
<h2>Cadastrar Cargo</h2>
<form method="post">
    <label>Nome:<br><input name="nome_cargo" required></label><br>
    <label>Descrição:<br><textarea name="descricao"></textarea></label><br>
    <label>Salário Base:<br><input name="salario_base" type="number" step="0.01"></label><br>
    <button type="submit">Salvar</button>
</form>
<p><a href="index.php">Voltar</a></p>
</body>
</html>
