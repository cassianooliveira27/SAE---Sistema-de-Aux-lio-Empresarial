<?php
require 'conect_bd.php';
$cargos = $conn->query("SELECT * FROM cargos ORDER BY nome_cargo");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_funcionario']);
    $cpf  = preg_replace('/\D/', '', $_POST['cpf_funcionario']);
    $idc  = intval($_POST['id_cargo']);
    $carga= intval($_POST['carga_horaria']);
    $sal  = floatval($_POST['salario']);
    $data = $_POST['data_admissao'];
    if ($nome && $cpf) {
        $stmt = $conn->prepare("INSERT INTO funcionarios (nome_funcionario, cpf_funcionario, id_cargo, carga_horaria, salario, data_admissao) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('ssii ds', $nome, $cpf, $idc, $carga, $sal, $data);
        $stmt->execute();
        header('Location: consulta_funcionarios.php');
        exit;
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8"><title>Cadastrar Funcionário</title>
<link rel="stylesheet" href="style.css">
<script>
function mascaraCPF(campo) {
    let v = campo.value.replace(/\D/g, '');
    v = v.replace(/(\d{3})(\d)/, '$1.$2');
    v = v.replace(/(\d{3})(\d)/, '$1.$2');
    v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    campo.value = v;
}
</script>
</head>
<body>
    <div class="header">
    <div class="header-content">
        <img src="logo.png" alt="SAE Logo" class="logo">
        <div>
            <h1 class="header-title">SAE</h1>
            <p class="header-subtitle">Sistema Auxiliar Empresarial</p>
        </div>
    </div>
</div>
<h2>Cadastrar Funcionário</h2>
<form method="post">
    <label>Nome:<br><input name="nome_funcionario" required></label><br>
    <label>CPF:<br><input name="cpf_funcionario" id="cpf" maxlength="14" oninput="mascaraCPF(this)" required></label><br>
    <label>Cargo:<br>
        <select name="id_cargo" required>
            <option value="">Selecione</option>
            <?php while($c = $cargos->fetch_assoc()): ?>
                <option value="<?=$c['id_cargo']?>"><?=htmlspecialchars($c['nome_cargo'])?></option>
            <?php endwhile; ?>
        </select>
    </label><br>
    <label>Carga Horária:<br><input type="number" name="carga_horaria" value="40"></label><br>
    <label>Salário:<br><input type="number" step="0.01" name="salario"></label><br>
    <label>Data de Admissão:<br><input type="date" name="data_admissao"></label><br>
    <button type="submit">Salvar</button>
</form>
<p><a href="index.php">Voltar</a></p>
</body>
</html>
