<?php
require 'conect_bd.php';

if (isset($_GET['excluir'])) {
    $id = intval($_GET['excluir']);
    $conn->query("DELETE FROM cargos WHERE id_cargo = $id");
    header("Location: consulta_cargos.php");
    exit;
}

if (isset($_GET['editar'])) {
    $id = intval($_GET['editar']);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nome = trim($_POST['nome_cargo']);
        $desc = trim($_POST['descricao']);
        $sal  = floatval($_POST['salario_base']);
        $stmt = $conn->prepare("UPDATE cargos SET nome_cargo=?, descricao=?, salario_base=? WHERE id_cargo=?");
        $stmt->bind_param('ssdi', $nome, $desc, $sal, $id);
        $stmt->execute();
        header("Location: consulta_cargos.php");
        exit;
    }
    $dados = $conn->query("SELECT * FROM cargos WHERE id_cargo=$id")->fetch_assoc();
    ?>
    <!doctype html>
    <html>
    <head>
        <meta charset="utf-8"><title>Editar Cargo</title>
                <link rel="stylesheet" href="style.css">
    </head>
    <body>
         <div class="header">
    <div class="header-content">
        <img src="logo.png" alt="SAE Logo" class="logo">
        <div>
            <h1 class="header-title">SAE</h1>
            <p class="header-subtitle">Sistema Auxiliar Empresarial</p>
        </div>
    </div>
</div>
    <h2>Editar Cargo</h2>
    <form method="post">
        <label>Nome:<input name="nome_cargo" value="<?=htmlspecialchars($dados['nome_cargo'])?>"></label>
        <label>Descrição:<textarea name="descricao"><?=htmlspecialchars($dados['descricao'])?></textarea></label>
        <label>Salário Base:<input type="number" step="0.01" name="salario_base" value="<?=$dados['salario_base']?>"></label>
        <button type="submit">Salvar Alterações</button>
    </form>
    <p><a href="consulta_cargos.php">Cancelar</a></p>
    </body>
    </html>
    <?php
    exit;
}

$pesquisa = $_GET['pesquisa'] ?? '';
$query = "SELECT * FROM cargos WHERE 1=1";
if ($pesquisa) {
    $pesq = $conn->real_escape_string($pesquisa);
    $query .= " AND nome_cargo LIKE '%$pesq%'";
}
$query .= " ORDER BY nome_cargo";
$res = $conn->query($query);
?>
<!doctype html>
<html>
<head>
             <link rel="stylesheet" href="style.css">
<meta charset="utf-8">
<title>Consulta Cargos</title>
<style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    table { border-collapse: collapse; width: 100%; margin-top: 10px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    th { background: #f4f4f4; }
    form.filtros { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; }
    form.filtros input, form.filtros button { padding: 6px; }
    @media(max-width: 600px) {
        table, thead, tbody, th, td, tr { display: block; width: 100%; }
        tr { margin-bottom: 10px; border: 1px solid #ddd; padding: 10px; }
        td { border: none; }
    }
</style>
</head>
<body>
     <div class="header">
    <div class="header-content">
        <img src="logo.png" alt="SAE Logo" class="logo">
        <div>
            <h1 class="header-title">SAE</h1>
            <p class="header-subtitle">Sistema Auxiliar Empresarial</p>
        </div>
    </div>
</div>
<h2>Consulta de Cargos</h2>

<form method="get" class="filtros">
    <input type="text" name="pesquisa" placeholder="Buscar cargo" value="<?=htmlspecialchars($pesquisa)?>">
    <button type="submit">Filtrar</button>
    <a href="consulta_cargos.php" style="padding:6px; background:#ccc; text-decoration:none;">Limpar</a>
</form>

<table>
<tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Descrição</th>
    <th>Salário Base</th>
    <th>Ações</th>
</tr>
<?php while($c = $res->fetch_assoc()): ?>
<tr>
    <td><?=$c['id_cargo']?></td>
    <td><?=htmlspecialchars($c['nome_cargo'])?></td>
    <td><?=htmlspecialchars($c['descricao'])?></td>
    <td><?=number_format($c['salario_base'],2,',','.')?></td>
    <td>
        <a href="?editar=<?=$c['id_cargo']?>">Editar</a> |
        <a href="?excluir=<?=$c['id_cargo']?>" onclick="return confirm('Tem certeza que deseja excluir?');">Excluir</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<p><a href="index.php">Voltar à Página Inicial</a></p>
</body>
</html>
