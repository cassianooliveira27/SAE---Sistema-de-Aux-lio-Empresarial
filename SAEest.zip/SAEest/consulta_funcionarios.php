<?php
require 'conect_bd.php';

if (isset($_GET['excluir'])) {
    $id = intval($_GET['excluir']);
    $conn->query("DELETE FROM funcionarios WHERE id_funcionario = $id");
    header("Location: consulta_funcionarios.php");
    exit;
}

if (isset($_GET['editar'])) {
    $id = intval($_GET['editar']);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nome  = trim($_POST['nome_funcionario']);
        $carga = intval($_POST['carga_horaria']);
        $sal   = floatval($_POST['salario']);
        $cargo = intval($_POST['id_cargo']);
        $stmt = $conn->prepare("UPDATE funcionarios SET nome_funcionario=?, carga_horaria=?, salario=?, id_cargo=? WHERE id_funcionario=?");
        $stmt->bind_param('sidii', $nome, $carga, $sal, $cargo, $id);
        $stmt->execute();
        header("Location: consulta_funcionarios.php");
        exit;
    }
    $dados = $conn->query("SELECT * FROM funcionarios WHERE id_funcionario=$id")->fetch_assoc();
    $cargos = $conn->query("SELECT * FROM cargos ORDER BY nome_cargo");
    ?>
    <!doctype html>
    <html>
    <head>
        <meta charset="utf-8"><title>Editar Funcionário</title>
        <link rel="stylesheet" href="style.css">
        <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            input, select, button { padding: 6px; margin: 4px 0; width: 100%; }
            form { max-width: 400px; margin: auto; }
        </style>
    </head>
    <body>
         <div class="header">
    <div class="header-content">
        <img src="logo.png" alt="SAE Logo" class="logo">
        <div>
            <h1 class="header-title">SAE</h1>
            <p class="header-subtitle">Sistema Auxiliar Empresarial</p>
        </div>
    </div>
</div>
    <h2>Editar Funcionário</h2>
    <form method="post">
        <label>Nome:<input name="nome_funcionario" value="<?=htmlspecialchars($dados['nome_funcionario'])?>"></label>
        <label>Cargo:
            <select name="id_cargo">
                <?php while($c = $cargos->fetch_assoc()): ?>
                    <option value="<?=$c['id_cargo']?>" <?=($dados['id_cargo'] == $c['id_cargo'] ? 'selected' : '')?>><?=htmlspecialchars($c['nome_cargo'])?></option>
                <?php endwhile; ?>
            </select>
        </label>
        <label>Carga Horária:<input type="number" name="carga_horaria" value="<?=$dados['carga_horaria']?>"></label>
        <label>Salário:<input type="number" step="0.01" name="salario" value="<?=$dados['salario']?>"></label>
        <button type="submit">Salvar Alterações</button>
    </form>
    <p><a href="consulta_funcionarios.php">Cancelar</a></p>
    </body>
    </html>
    <?php
    exit;
}

$pesquisa = $_GET['pesquisa'] ?? '';
$cargo_filtro = $_GET['cargo'] ?? '';
$salario_filtro = $_GET['salario'] ?? '';
$query = "SELECT f.*, c.nome_cargo FROM funcionarios f LEFT JOIN cargos c ON f.id_cargo = c.id_cargo WHERE 1=1";

if ($pesquisa) {
    $pesq = $conn->real_escape_string($pesquisa);
    $query .= " AND f.nome_funcionario LIKE '%$pesq%'";
}
if ($cargo_filtro) {
    $cargo_filtro = intval($cargo_filtro);
    $query .= " AND f.id_cargo = $cargo_filtro";
}
if ($salario_filtro) {
    $salario_filtro = floatval($salario_filtro);
    $query .= " AND f.salario >= $salario_filtro";
}

$query .= " ORDER BY f.nome_funcionario";

$res = $conn->query($query);
$cargos = $conn->query("SELECT * FROM cargos ORDER BY nome_cargo");
?>
<!doctype html>
<html>
<head>
       <link rel="stylesheet" href="style.css">
<meta charset="utf-8">
<title>Consulta Funcionários</title>
<style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    table { border-collapse: collapse; width: 100%; margin-top: 10px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    th { background: #f4f4f4; }
    form.filtros { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; }
    form.filtros input, form.filtros select, form.filtros button { padding: 6px; }
    @media(max-width: 600px) {
        table, thead, tbody, th, td, tr { display: block; width: 100%; }
        tr { margin-bottom: 10px; border: 1px solid #ddd; padding: 10px; }
        td { border: none; }
    }
</style>
</head>
<body>
          <div class="header">
    <div class="header-content">
        <img src="logo.png" alt="SAE Logo" class="logo">
        <div>
            <h1 class="header-title">SAE</h1>
            <p class="header-subtitle">Sistema Auxiliar Empresarial</p>
        </div>
    </div>
</div>
<h2>Consulta de Funcionários</h2>

<form method="get" class="filtros">
    <input type="text" name="pesquisa" placeholder="Buscar por nome" value="<?=htmlspecialchars($pesquisa)?>">
    <input type="number" step="0.01" name="salario" placeholder="Salário mínimo" value="<?=htmlspecialchars($salario_filtro)?>">
    <select name="cargo">
        <option value="">Todos os cargos</option>
        <?php while($c = $cargos->fetch_assoc()): ?>
            <option value="<?=$c['id_cargo']?>" <?=($cargo_filtro == $c['id_cargo'] ? 'selected' : '')?>><?=htmlspecialchars($c['nome_cargo'])?></option>
        <?php endwhile; ?>
    </select>
    <button type="submit">Filtrar</button>
    <a href="consulta_funcionarios.php" style="padding:6px; background:#ccc; text-decoration:none;">Limpar</a>
</form>

<table>
<tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Cargo</th>
    <th>Carga Horária</th>
    <th>Salário</th>
    <th>Ações</th>
</tr>
<?php while($f = $res->fetch_assoc()): ?>
<tr>
    <td><?=$f['id_funcionario']?></td>
    <td><?=htmlspecialchars($f['nome_funcionario'])?></td>
    <td><?=htmlspecialchars($f['nome_cargo'])?></td>
    <td><?=$f['carga_horaria']?></td>
    <td><?=number_format($f['salario'],2,',','.')?></td>
    <td>
        <a href="?editar=<?=$f['id_funcionario']?>">Editar</a> |
        <a href="?excluir=<?=$f['id_funcionario']?>" onclick="return confirm('Tem certeza que deseja excluir?');">Excluir</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<p><a href="index.php">Voltar à Página Inicial</a></p>
</body>
</html>
