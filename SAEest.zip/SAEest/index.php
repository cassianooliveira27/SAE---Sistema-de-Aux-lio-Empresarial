<?php require 'conect_bd.php'; ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>SAE - Menu</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    a { display: inline-block; margin: 8px 0; text-decoration: none; background: #007BFF; color: white; padding: 6px 10px; border-radius: 4px; }
    a:hover { background: #0056b3; }
  </style>
</head>
<body>
<body>
<div class="header">
    <div class="header-content">
        <img src="logo.png" alt="SAE Logo" class="logo">
        <div>
            <h1 class="header-title">SAE</h1>
            <p class="header-subtitle">Sistema Auxiliar Empresarial</p>
        </div>
    </div>
</div>

<div class="container">
    <nav>
        <div class="nav-card">
            <a href="cargos.php">
                📋 Cadastrar Cargo
            </a>
        </div>
        <div class="nav-card">
            <a href="funcionarios.php">
                👤 Cadastrar Funcionário
            </a>
        </div>
        <div class="nav-card">
            <a href="consulta_cargos.php">
                📊 Consultar Cargos
            </a>
        </div>
        <div class="nav-card">
            <a href="consulta_funcionarios.php">
                👥 Consultar Funcionários
            </a>
        </div>
    </nav>
</div>
</body>
</body>
</html>
